<!DOCTYPE html>
<html lang="en">
  <?php
  include "sidebar.php";
  ?>
    <head>
        <title>SPP</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="header/css/style.css">
     </head>
     <body>
       <div id="content" class="p-4 p-md-5 pt-5">
         <h3>Tampil Petugas  |  <a href="tambah_petugas.php" class="btn btn-primary">Tambah Petugas</a></h3>
         <table class="table table-hover table-striped">
           <thead>
             <tr>
               <th>NO</th>
               <th>NAMA</th>
               <th>USERNAME</th>
               <th>LEVEL</th>
               <th>AKSI</th>
             </tr>
            </thead>
            <tbody>
              <?php 
              include "koneksi.php";
              $qry_petugas=mysqli_query($conn,"select * from petugas");
              $no=0;
              while($data_petugas=mysqli_fetch_array($qry_petugas)){
                $no++;?>
                <tr>
                  <td><?=$no?></td>
                  <td><?=$data_petugas['nama_petugas']?></td>
                  <td><?=$data_petugas['username']?></td>
                  <td><?=$data_petugas['level']?></td>
                  <td><a href="ubah_petugas.php?id_petugas=<?=$data_petugas['id_petugas']?>" class="btn btn-success">Ubah</a> | <a href="hapus_petugas.php?id_petugas=<?=$data_petugas['id_petugas']?>" onclick="return confirm('Apakah anda yakin menghapus data ini?')" class="btn btn-danger">Hapus</a></td>
                </tr>
                <?php 
                }
                ?>
                </tbody>
              </table>
            </div>
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
          </body>    
          </html>
