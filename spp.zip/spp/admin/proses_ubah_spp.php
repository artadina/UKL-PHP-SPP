<?php
include("koneksi.php");
if(isset($_POST['simpan'])){
    $id_spp = $_POST['id_spp'];
    $angkatan = $_POST['angkatan'];
    $tahun = $_POST['tahun'];
    $nominal = $_POST['nominal'];

    $sql = "UPDATE spp SET angkatan='$angkatan', tahun='$tahun', nominal='$nominal' WHERE id_spp=$id_spp";
    $query = mysqli_query($conn, $sql);

    if($query){
        header('Location: tampil_spp.php');
    }else{
        die("Gagal menyimpan perubahan");
    }
}
?>